brackets-autoindent-extension
============================

This extension adds auto-indent function to Adobe Brackets.

If you install this extension, you can invoke by "Edit > Auto Indent" menu or "Ctrl+Shift+I" key.

Install
===

Please download zip and extract into arbitrary directory (or clone source files), then move the folder to the extensions folder (you can open this folder by clicking "Help > Show Extensions Folder" menu).

License
===
This software is licensed under MIT license.